/*
 * Copyright (C) 2015 Intel Corporation. All rights reserved.
 *
 * App Framework will use a 'native' theme unless told not to.
 */
/*global af */

(function()
 {
  "use strict";
  var appf = af || $;
  appf.ui.useOSThemes = false;
 })();
